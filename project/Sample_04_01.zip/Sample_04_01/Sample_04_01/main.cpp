﻿// ConsoleApplication1.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <iostream>

// step-1 MyArrayクラスを作成する。


int main()
{
    // step-2 MyArrayクラスを使ってみる。


    return 0;
}



